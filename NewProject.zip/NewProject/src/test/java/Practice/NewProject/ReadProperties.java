package Practice.NewProject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import net.sourceforge.htmlunit.corejs.javascript.tools.debugger.Main;

public class ReadProperties {

	private Properties obj = null;
	private FileInputStream objfile = null;
	
	public ReadProperties(){
		try {
		
			obj = new Properties();
			objfile = new FileInputStream(System.getProperty("user.dir") + "\\objects.properties");
			obj.load(objfile);
			
		} catch (FileNotFoundException e) {
						e.printStackTrace();
		} catch (IOException e) {
						e.printStackTrace();
		}
	}	
	
	public String property(String key) throws IOException{
				return obj.getProperty(key);
	}
	

}
package Practice.NewProject;

/**
 * Hello world!
 *
 */
public class AppTest 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
